package com.example.gaurav.kitchenmasterchef;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Submit extends AppCompatActivity {
    //Spinner spinner;
    EditText RECIPE_NAME, CUISINE_TYPE, INGREDIENTS, METHOD;
    Button SUBMIT;
    String recipe_name, cuisine_type, ingredients, method;
    Context ctx = this;
    ArrayAdapter<CharSequence> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit);



        RECIPE_NAME = findViewById(R.id.recipe_name1);
        CUISINE_TYPE = findViewById(R.id.cuisine1);
        INGREDIENTS = findViewById(R.id.ingredients1);
        METHOD = findViewById(R.id.method);
        SUBMIT = findViewById(R.id.submitB);
        SUBMIT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recipe_name = RECIPE_NAME.getText().toString();
                cuisine_type = CUISINE_TYPE.getText().toString();
                ingredients = INGREDIENTS.getText().toString();
                method = METHOD.getText().toString();

                DatabaseOperations DB = new DatabaseOperations(ctx);
                DB.putInformation(DB, recipe_name, cuisine_type, ingredients, method);
                Toast.makeText(getBaseContext(), "Recipe Added", Toast.LENGTH_LONG).show();
                finish();

            }
        });

    }

}
