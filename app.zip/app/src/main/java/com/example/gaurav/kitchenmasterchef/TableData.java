package com.example.gaurav.kitchenmasterchef;

import android.provider.BaseColumns;

public class TableData {

    public TableData(){


    }

    public static abstract class TableInfo implements BaseColumns{

        public static final String RECIPE_NAME = "recipe_name";
        public static final String CUISINE_TYPE = "cuisine_type";
        public static final String INGREDIENTS = "ingredients";
        public static final String METHOD = "recipe_method";
        public static final String DATABASE_NAME = "cook_info";
        public static final String TABLE_NAME = "recipe_info";


    }
}
