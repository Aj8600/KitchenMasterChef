package com.example.gaurav.kitchenmasterchef;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

public class RecipeDetailed extends AppCompatActivity {

    public String recipe_num;
    TextView view1, view2, view3, view4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detailed);
        Intent detailedIntent = this.getIntent();
        if (detailedIntent != null && detailedIntent.hasExtra(Intent.EXTRA_TEXT)){
            recipe_num = detailedIntent . getStringExtra(Intent.EXTRA_TEXT) ;
            Toast.makeText(this, recipe_num, Toast.LENGTH_SHORT).show();
        }
        show_entries();
    }

    private void show_entries() {
        DatabaseOperations DOP = new DatabaseOperations(getApplicationContext());
        SQLiteDatabase SQ = DOP.getReadableDatabase();
        //Cursor c = SQ.rawQuery("SELECT * FROM " + TableData.TableInfo.TABLE_NAME + " WHERE " + TableData.TableInfo.RECIPE_NAME + " = " + recipe_num + " ;", null);
        String p_query = "select * from recipe_info where recipe_name =?";
        Cursor c = SQ.rawQuery(p_query, new String[]{recipe_num});


        while(c.moveToNext()){

            String name = c.getString(c.getColumnIndex(TableData.TableInfo.RECIPE_NAME));
            view1 = findViewById(R.id.view);
            view1.setText("Recipe Name:\n" + name);
            String cui = c.getString(c.getColumnIndex(TableData.TableInfo.CUISINE_TYPE));
            view2 = findViewById(R.id.textView8);
            view2.setText("Cuisine Type\n" + cui);
            String ingre = c.getString(c.getColumnIndex(TableData.TableInfo.INGREDIENTS));
            view3 = findViewById(R.id.textView9);
            view3.setText("Ingredients:\n" + ingre);
            String metho = c.getString(c.getColumnIndex(TableData.TableInfo.METHOD));
            view4 = findViewById(R.id.textView10);
            view4.setText("Method:\n" + metho);

        }
    }

}
