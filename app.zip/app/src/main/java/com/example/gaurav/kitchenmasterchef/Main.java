package com.example.gaurav.kitchenmasterchef;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button1 = (Button) findViewById(R.id.submit);
        Button button2 = (Button) findViewById(R.id.find);

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){

                Intent myIntent = new Intent(Main.this,Search.class);
                startActivity(myIntent);
            }

        });

        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0){

                Intent myIntent = new Intent(Main.this,Submit.class);
                startActivity(myIntent);
            }

        });

    }

}
