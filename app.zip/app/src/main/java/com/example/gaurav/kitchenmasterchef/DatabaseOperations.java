package com.example.gaurav.kitchenmasterchef;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DatabaseOperations extends SQLiteOpenHelper {
    public static int database_version = 1;
    public String CREATE_QUERY = "CREATE TABLE IF NOT EXISTS" + TableData.TableInfo.TABLE_NAME+"("+ TableData.TableInfo.RECIPE_NAME+" TEXT,"+ TableData.TableInfo.CUISINE_TYPE+" TEXT,"+ TableData.TableInfo.INGREDIENTS+" TEXT,"+ TableData.TableInfo.METHOD+" TEXT );";

    public DatabaseOperations(Context context){
        super(context, TableData.TableInfo.DATABASE_NAME, null, database_version);
        Log.d("Database Operations", "Database created");

    }

    private static final String DELETE_QUERY = "DROP TABLE IF EXISTS " + TableData.TableInfo.TABLE_NAME;

    @Override
    public void onCreate(SQLiteDatabase sdb) {
        sdb.execSQL(CREATE_QUERY);
        Log.d("Database Operations", "Table created");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sdb, int i, int i1) {

        sdb.execSQL(DELETE_QUERY);
        onCreate(sdb);

    }

    public void putInformation(DatabaseOperations dop, String name, String type, String ingredients, String method){

        SQLiteDatabase SQ = dop.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(TableData.TableInfo.RECIPE_NAME, name);
        cv.put(TableData.TableInfo.CUISINE_TYPE, type);
        cv.put(TableData.TableInfo.INGREDIENTS, ingredients);
        cv.put(TableData.TableInfo.METHOD, method);
        long k = SQ.insert(TableData.TableInfo.TABLE_NAME, null, cv);
        Log.d("Database Operations", "One Entry Inserted");

    }

    public Cursor getInformation(DatabaseOperations dop){

        SQLiteDatabase SQ = dop.getReadableDatabase();
        //String[] coloumns = {TableData.TableInfo.RECIPE_NAME};
        //Cursor CR = SQ.query(TableData.TableInfo.TABLE_NAME, coloumns,null, null, null, null, null);

        Cursor CR = SQ.rawQuery("SELECT " + TableData.TableInfo.RECIPE_NAME + " from " + TableData.TableInfo.TABLE_NAME, new String[] {});

        return CR;
    }
}
