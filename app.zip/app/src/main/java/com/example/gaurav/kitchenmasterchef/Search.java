package com.example.gaurav.kitchenmasterchef;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.List;

public class Search extends AppCompatActivity{
    MaterialSearchView searchView;
    ListView lstView;
    Context CTX = this;
    ArrayList<String> array = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //getSupportActionBar().setTitle("Material Search");
        toolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));

        DatabaseOperations DOP = new DatabaseOperations(CTX);
        Cursor CR = DOP.getInformation(DOP);
        /*CR.moveToFirst();
        array = new String[CR.getCount()];
        int i = 0;
        while(CR.moveToNext()){
            String uname = CR.getString(CR.getColumnIndex(TableData.TableInfo.RECIPE_NAME));
            array[i] = uname;
            i++;
        }*/


        while (CR.moveToNext()) {
            String uname = CR.getString(CR.getColumnIndex(TableData.TableInfo.RECIPE_NAME));
            array.add(uname);

        }



        lstView = findViewById(R.id.lstView);
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, array);
        lstView.setAdapter(adapter);

        searchView = findViewById(R.id.search_view);

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {

            }

            @Override
            public void onSearchViewClosed() {

                lstView = findViewById(R.id.lstView);
                ArrayAdapter adapter = new ArrayAdapter(Search.this, android.R.layout.simple_list_item_1, array);
                lstView.setAdapter(adapter);

            }
        });

        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(newText != null && !newText.isEmpty()){
                    List<String> lstFound = new ArrayList<>();
                    for(String item:array){
                        if(item.contains(newText))
                            lstFound.add(item);
                    }

                    ArrayAdapter adapter = new ArrayAdapter(Search.this, android.R.layout.simple_list_item_1, lstFound);
                    lstView.setAdapter(adapter);
                }
                else{
                    ArrayAdapter adapter = new ArrayAdapter(Search.this, android.R.layout.simple_list_item_1, array);
                    lstView.setAdapter(adapter);
                }
                return true;

            }


        });

        lstView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //String item = (String) adapter.getItem(i);
                String recipe_num = array.get(i);
                Intent intent = new Intent(getApplicationContext(), RecipeDetailed.class);
                intent.putExtra(Intent.EXTRA_TEXT, recipe_num + "");
                startActivity(intent);
            }
        });

        CR.close();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_item, menu);
        MenuItem item = menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;

    }

}
